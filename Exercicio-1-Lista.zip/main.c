#include <stdio.h>

int main(void) {
  int e_nro_1, e_nro_2, e_nro_3;
  printf("Entre com o valor do nro 1: "); 
  scanf("%i", &e_nro_1);
  printf("Entre com o valor do nro 2: ");
  scanf("%i", &e_nro_2);
  printf("Entre com o valor do nro 3: ");  
  scanf("%i", &e_nro_3);

  if(e_nro_1 > e_nro_2){
    
    if(e_nro_2 > e_nro_3){

      printf("%d - %d - %d", e_nro_3, e_nro_2, e_nro_1);
      
    }else{
      printf("%d - %d - %d", e_nro_2, e_nro_3, e_nro_1);


         }  
    }     
else{

  if (e_nro_1 > e_nro_3){
    printf("%d - %d - %d", e_nro_3, e_nro_1, e_nro_2);
  
  }else{
    if(e_nro_2 > e_nro_3){
      printf("%d - %d - %d", e_nro_1, e_nro_3, e_nro_2);

    }else{ 
      printf("%d - %d - %d", e_nro_1, e_nro_2, e_nro_3);
    }
  }
}  
    






  return 0;
}